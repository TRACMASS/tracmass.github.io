---
title: TRACMASS publications
subtitle: a non-exhaustive list
layout: page
image: images/headers_footer/fig_header.png
---

Dey, D., and Döös, K. (2020). Atmospheric Freshwater Transport From the Atlantic to the Pacific Ocean: A Lagrangian Analysis. Geophysical Research Letters, 47(6), e2019GL086176. <a class="trmLnk" href="https://agupubs.onlinelibrary.wiley.com/doi/pdf/10.1029/2019GL086176" target="_blank">Link</a>

Berglund, S., Döös, K., and Nycander, J. (2017). Lagrangian tracing of the water–mass transformations in the Atlantic Ocean. Tellus A: Dynamic Meteorology and Oceanography, 69(1), 1306311. <a class="trmLnk" href="https://www.tandfonline.com/doi/pdf/10.1080/16000870.2017.1306311" target="_blank">Link</a>

Döös, K., J. Kjellsson, and B. F. Jönsson (2013), TRACMASS - A Lagrangian Trajectory Model, in Preventive Methods for Coastal Protection, edited by T. Soomere and E. Quak, Springer International Publishing.
<a class="trmLnk" href="https://link.springer.com/chapter/10.1007/978-3-319-00440-2_7" target="_blank">Link</a>

Kjellsson, J., K. Döös, and T. Soomere (2013), Evaluation and Tuning of Model Trajectories and Spreading Rates in the Baltic Sea using Surface Drifter Observations, in Preventive Methods for Coastal Protection, edited by T. Soomere and E. Quak, Springer International Publishing.
<a class="trmLink" href="https://link.springer.com/chapter/10.1007/978-3-319-00440-2_8" target="_blank">Link</a>

Kjellsson, J., and K. Döös (2012a), Lagrangian decomposition of the Hadley and Ferrel Cells, Geophys. Res. Lett., 39(L15807)
<a class="trmLnk" href="http://onlinelibrary.wiley.com/doi/10.1029/2012GL052420/full" target="_blank">Link</a>

Kjellsson, J., and K. Döös (2012b), Surface drifters and model trajectories in the Baltic Sea, Boreal Environment Research, 17, 447--459.
<a class="trmLnk" href="https://www.diva-portal.org/smash/get/diva2:563137/FULLTEXT01.pdf" target="_blank">Link</a>

Döös, K., J. Nycander, and A. C. Coward (2008), Lagrangian decomposi-
tion of the Deacon Cell, J. Geophys. Res., 113, C07028, doi:10.1029/
2007JC004351.
<a class="trmLnk" href="http://onlinelibrary.wiley.com/doi/10.1029/2007JC004351/abstract" target="_blank">Link</a>

Döös, K. (1995), Interocean exchange of water masses, J. Geophys. Res., 100, 13,499–13,514.
<a class="trmLnk" href="http://onlinelibrary.wiley.com/doi/10.1029/95JC00337/abstract" target="_blank">Link</a>
