---
title: TRACMASS news & updates
subtitle: ''
layout: page
image: images/headers_footer/fig_header.png
---
## Release of version 7.0
*18/12/2020*

<p align="center">
  <img width="30%" src="/images/fig_v7logo.png">
</p>

A new version of **TRACMASS** (v7.0-beta) is now available. This version includes the following new features:

- The code has been thoroughly cleaned up
- Supported test cases from:
    - Ocean circulation models: 	*NEMO, MOM5, ROMS*
    - Satellite ocean current data 	*AVISO*
    - Atmospheric circulation model data 	*IFS* (ERA-Interim, EC-Earth)
- Any tracer can be followed e.g. biogeochemical tracers or chemical compounds in the atmosphere.
- A new quick-start guide and a comprehensive documentation.
