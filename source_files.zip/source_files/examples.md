---
title: Example Gallery
sections:
  - section_id: hero
    type: section_hero
    title: Example gallery
    image: images/headers_footer/fig_header.png
    content: |
      Video and Image galleries of different results computed with **TRACMASS**
  - title: Video Gallery
    section_id: lorem-ipsum
    subtitle: Some trajectory examples computed using TRACMASS
    col_number: two
    grid_items:
      - title: Conveyor belt
        title_url: ''
        image_alt: ''
        content: >
          <iframe width="560" height="315" src="https://www.youtube.com/embed/3-LI45Z6_qs" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        actions: []
        type: grid_item
      - title: Particles in the Agulhas current system.
        title_url: ''
        image_alt: ''
        content: >
          <iframe width="560" height="315" src="https://www.youtube.com/embed/UOpxBc-bcds" frameborder="0" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
        actions: []
        type: grid_item
    type: section_grid
  - title: Image gallery
    section_id: lorem-ipsum
    subtitle: Includes examples of different TRACMASS features
    col_number: two
    grid_items:
      - title: Theoretical case
        title_url: /blog/theoretical
        image_alt: lorem-ipsum
        content: >
          The theoretical is the default project of TRACMASS and describes the
          flow on a spatial homogeneous and time dependent two dimensional
          velocity field.
        actions:
          - label: See gallery
            url: /blog/theoretical
            style: link
            icon_class: dev
            new_window: false
            no_follow: false
            type: action
        type: grid_item
        image:  images/fig_theo_intro.png
      - title: AVISO (satellite altimetry data)
        title_url: /blog/aviso
        image_alt: lorem-ipsum
        content: >
          The AVISO data is stored on a Arakawa’s B-grid while TRACMASS is
          defined on a Arakawa’s C-grid. Therefore, both zonal and meridional
          fluxes are computed interpolating the velocity fields on the TRACMASS
          grid. This is done on the read_field subroutine.
        actions:
          - label: See gallery
            url: /blog/aviso
            style: link
            icon_class: dev
            new_window: false
            no_follow: false
            type: action
        type: grid_item
        image: images/fig_aviso_intro.png
      - title: NEMO
        title_url: /blog/nemo
        image_alt: lorem-ipsum
        content: >
          The NEMO data is defined on the same grid as the TRACMASS grid.
          Therefore, there is no need to interpolate velocities or tracer on the
          TRACMASS grid.
        actions:
          - label: See gallery
            url: /blog/nemo
            style: link
            icon_class: dev
            new_window: false
            no_follow: false
            type: action
        type: grid_item
        image: images/fig_nemo_intro.png
      - title: ROMS
        title_url: /blog/roms
        image_alt: lorem-ipsum
        content: >
          The ROMS data is defined on the same grid as the TRACMASS grid.
          Therefore, there is no need to interpolate velocities or tracer on the
          TRACMASS grid. However, ghosts u and v points are defined around the
          frame to adjust to the TRACMASS grid.
        actions:
          - label: See gallery
            url: /blog/roms
            style: link
            icon_class: dev
            new_window: false
            no_follow: false
            type: action
        type: grid_item
        image: images/fig_roms_intro.png
      - title: IFS-ECMWF
        title_url: /blog/ifs
        image_alt: lorem-ipsum
        content: >
          The IFS data is stored on a Arakawa’s A-grid while TRACMASS is defined
          on a Arakawa’s C-grid. Therefore, both zonal and meridional fluxes are
          computed interpolating the velocity fields on the TRACMASS grid. This
          is done on the read_field subroutine.
        actions:
          - label: See gallery
            url: /blog/ifs
            style: link
            icon_class: dev
            new_window: false
            no_follow: false
            type: action
        type: grid_item
        image: images/fig_ifs_intro.png
    type: section_grid
layout: advanced
---
