window.addMainNavigationHandlers();
window.addDocsNavigationHandlers();
window.addPageNavLinks();