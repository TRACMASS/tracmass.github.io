window.removeMainNavigationHandlers();
window.removeDocsNavigationHandlers();
window.removePageNavLinks();