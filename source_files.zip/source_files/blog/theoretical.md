---
title: Theoretical case
subtitle:
image: images/headers_footer/fig_header.png
layout: post
---
<script src='https://cdnjs.cloudflare.com/ajax/libs/mathjax/2.7.4/MathJax.js?config=default'></script>

The theoretical is the default project of TRACMASS and describes the flow on a spatial homogeneous and time dependent two dimensional velocity field. The velocities are described by:

$$
      u(x,y,t) \equiv u(t)  =  u_g \exp(-\gamma_g t) + (u_o-u_g) \exp(-\gamma t) \cos(f t) \\

      v(x,y,t) \equiv v(t)  =  -(u_0-u_g) \exp(-\gamma t) \sin(f t)
$$

We used the same coefficients as Fabbroni (2009) with $$u_0 =$$ 0.3 m/s, $$u_g =$$ 0.04 m/s, and a damping time $$1/\gamma =$$ 2.89 days and $$1/\gamma_g =$$ 28.9 days. The latitude was set to $$ 45^\circ$$N. The velocities are read into TRACMASS every hour. TRACMASS was integrated forward in time using the time step method with intermediate steps so that the velocities were updated with linear interpolation between two time steps. The results are shown in the figure below, the small differences between the results from the truly analytical solution and the TRACMASS solution are likely due to the velocities are read every hour and not continuously.

<p align="center">
  <img width="60%" src="/images/fig_theo_1.png">
</p>

***
### TRACMASS features: *iter* choice
The results of TRACMASS are sensitive to the choice of **iter**. The higher value of **iter**, the more accurate the result of TRACMASS, however it will increase the computation time. The theoretical case is run with different **iter** values. As expected the highest value of **iter** is closer to the analytical solution while the deviation to the analytical solution becomes largest to the coarser case.

<p align="center">
  <img width="100%" src="/images/fig_theo_2.png">
</p>

***

<p align="center">
<a style="display: inline-block;" href="/examples"><img width="30px" src="/images/headers_footer/fig_house_symbol.png"> <a style="text-decoration: none;inline-block;" href="/blog/aviso"> &nbsp; &nbsp; &nbsp; Next gallery  <img width="30px" src="/images/headers_footer/fig_arrow_right.png">    </a>
</a>  
</p>
