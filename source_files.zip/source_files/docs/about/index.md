---
title: About
excerpt: >-
  Libris is a Unibit theme created for project documentations. You can use it
  for your project.
layout: docs
---
The original feature of the **TRACMASS** method is that it solves the trajectory path through each grid cell with an analytical solution of a differential equation which depends on the ve- locities on the grid-box walls. The scheme was originally developed by Döös (1995) and Blanke and Raynaud (1997) for stationary velocity fields and hereafter further de- veloped by Vries and Döös (2001) for time-dependent fields by solving a linear inter- polation of the velocity field both in time and in space over each grid box. This is in contrast to the time schemes such as simple Euler forward or more advanced fourth order Runge-Kutta methods (Butcher, 2008; Fabbroni, 2009) where the trajectories are integrated forward in time with as short time steps as possible.

The Lagrangian trajectory approach has many similarities with the Eulerian tracer approach but at the same time many differences. The two approaches are often con- fused due to their similarities. They are both advected passively by the velocity fields of the GCM, which makes it possible to trace water/air masses or substances such as pollutants as they are carried with the ocean currents or winds. The tracer equation generally needs to be integrated ‘on-line’ with the GCM while the Lagrangian trajectories can be both ‘on-line’ and ‘off-line’. The ‘off-line’ calculation of Lagrangian trajectories is by far the most rapid way since one only needs to read the already simulated velocity fields in order to calculate the trajectories.

The **TRACMASS** code has been further developed over the years and used in many studies of the global ocean (Döös and Coward, 1997; Drijfhout et al., 2003; Döös et al., 2008, Berglund et al. 2017) and regional ones for the Mediterranean and Baltic Seas (Döös et al., 2004; Jönsson et al., 2004; Engqvist et al. , 2006; Soomere et al., 2011) as well as the large scale atmospheric circulation (Kjellsson and Döös, 2012).

The code was originally written in Fortran 77 for the FRAM ocean model at the Institute of Oceanographic Sciences, Deacon Laboratory (IOSDL) in Wormley, UK in the early 90’s. The name **TRACMASS** comes from the EU project with the same name, where it served together with the similar trajectory code Ariane by Blanke and Raynaud (1997). The present code is written in Fortran 90 and can be driven by velocity fields from most GCMs based on finite differences. The **TRACMASS** code is continuously upgraded and adapted. 

