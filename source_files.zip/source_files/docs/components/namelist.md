---
title: <p>Namelist</p>
weight: 1
layout: docs
---

Many variables at TRACMASS can be modified using the namelist without the need to recompile the program. Each project has a *namelist_CASE.in* in the project folder. When TRACMASS is compiled a copy of the namelist (*namelist.in*) can be found in the main TRACMASS directory.

This is a list of all the variables that can be changed in the namelist and their corresponding group.

### INIT_GRID_DESCRIPTION
Here you can set the paths and variable names to define the volume/mass fluxes.

* **griddir** [*integer, array*]: the direction of the input data indexes referenced to the TRACMASS reference system. It's a three element array; the first element corresponds to the zonal direction, the second one to the meridional direction and the third one to the vertical direction. Two possible values are possible (1) eastward/northward/upward or (-1) westward/southward/downward. The default values are **[1,1,1]**.

* **zeroindx** [*logical*]: the first index in the original dataset is given by zero instead of one. The default value is **FALSE**.

* **trunit** [*real*]: constant to scale the TRACMASS transports.

* **l_onestep** [*logical*]: read one time step per input file. The default value is **FALSE**.

* **physDataDir** [*character*]: path to the input data directory.

* **physPrefixForm** [*character*]: prefix of the input data file name.

* **dateFormat** [*character*]: part of the input data name that will be corrected by the subroutine **filledFileName**.

* **tGridName** [*character*]: the suffix for T grid files.

* **uGridName** [*character*]: the suffix for U grid files.

* **vGridName** [*character*]: the suffix for V grid files.

* **fileSuffix** [*character*]: describes the file format of the input files such as 'nc' or 'nc4'.

* **hs_name** [*character*]: variable name for surface height/pressure, etc.

* **ueul_name** [*character*]: variable name for zonal velocity.

* **veul_name** [*character*]: variable name for meridional velocity.

* **usgs_name** [*character*]: variable name for subgrid zonal velocity. The default value is **" "**.

* **vsgs_name** [*character*]: variable name for subgrid meridional velocity. The default value is **" "**.

* **usub_name** [*character*]: variable name for secondary subgrid zonal velocity. The default value is **" "**.

* **vsub_name** [*character*]: variable name for secondary subgrid meridional velocity. The default value is **" "**.

* **w_name** [*character*]: variable name for vertical velocity. The default value is **" "**.

### INIT_GRID_SIZE
Here you can set the paths to the files that contain the mesh grid as well as defined the size or the domain or the type of boundary conditions.

* **imt** [*integer*]: number of global i points.

* **jmt** [*integer*]: number of global j points.

* **km** [*integer*]: number of global k points.

* **nst** [*integer*]: number of time levels to use. The default values is **2**.

* **iperio** [*integer*]: zonal boundary conditions. Two possible values: (0) no zonal boundary condition or (1) zonal conditions is on. The default values is **0**.

* **jperio** [*integer*]: meridional boundary conditions. Two possible values: (0) no meridional boundary condition or (1) meridional condition is on. The default values is **0**.

* **topoDataDir** [*character*]: path to the directory that contains mesh or topography data.

* **hgridFile** [*character*]: name of the file that contains variables linked to horizontal grid data.

* **dy_name** [*character*]:  variable name for dy in T points.

* **dyu_name** [*character*]:  variable name for dy in U points.

* **dx_name** [*character*]:  variable name for dx in T points.

* **dxv_name** [*character*]:  variable name for dx in V points.

* **zgridFile** [*character*]: name of the file that contains variables linked to vertical grid data.

* **dzt_name** [*character*]:  variable name for dz in T points.

* **dzu_name** [*character*]:  variable name for dz in U points.

* **dzv_name** [*character*]:  variable name for dz in V points.

* **dep_name** [*character*]:  variable name for total depth.

* **bathyFile** [*character*]: name of the file that contains variables linked to bathymetry/topography.

* **kmt_name** [*character*]:  variable name for bathymetry.

### INIT_GRID_SUBDOMAIN
Here you can activate and define a subdomain in TRACMASS (more info can be found [here](/docs/components/main_modules/#mod_subdomainf90)).

* **l_subdom** [*logical*]:  activate a subdomain. Default value is **FALSE**.

* **imindom** [*integer*]:  index that represents the western boundary of the subdomain.

* **imaxdom** [*integer*]:  index that represents the eastern boundary of the subdomain.

* **jmindom** [*integer*]:  index that represents the southern boundary of the subdomain.

* **jmaxdom** [*integer*]:  index that represents the northern boundary of the subdomain.

### INIT_GRID_TIME
Here you can set the time step and unit at which the input data is stored, as well as define the number of subcycles use in TRACMASS.

* **ngcm_step** [*integer*]:  number of time steps between two time levels.

* **ngcm_unit** [*integer*]:  unit of the time step: (1) seconds, (2) minutes, (3) hours, (4) days, (5) months, and (6) years.

* **iter** [*integer*]:  number of subcycles between time levels.

### INIT_START_DATE
Here you can define the starting date of the simulation.

* **startSec** [*integer*]:  starting second.

* **startMin** [*integer*]:  starting minute.

* **startHour** [*integer*]:  starting hour.

* **startDay** [*integer*]:  starting day.

* **startMonth** [*integer*]:  starting month.

* **startYear** [*integer*]:  starting year.

* **noleap** [*logical*]:  if FALSE a calendar with leap years is used. Default value is **TRUE**.

### INIT_RUN_TIME
Here you can define the number of time steps that TRACMASS will be run as well as define a loop between two dates (more info can be found [here](/docs/components/main_modules/#mod_calendarf90)).

* **loopYears** [*logical*]:  make a loop over two dates to run. Default value is **FALSE**.

* **loopStartYear** [*integer*]:  starting year of the loop.

* **loopEndYear** [*integer*]:  last year of the loop.

* **log_level** [*integer*]: level of verbose.

* **intrun** [*integer*]: number of time steps to run.

### INIT_WRITE_TRAJ
Here you can define all the parameters and paths linked to the output data (more info can be found [here](/docs/components/main_modules/#mod_writef90)).

* **write_frec** [*integer*]: output writing frequency: (1) write at time intervals of gcm datasets (each ints), (2) write at each time iteration, (3) write each spatial grid-crossing, (4) write at all time steps, and (5) write only start and end positions.

* **write_form** [*integer*]: output writing format: (0) two decimals, (1) five decimals. Default values is zero.

* **outDataDir** [*character*]:  path to the directory where the output files are stored.

* **outDataFile** [*character*]: prefix of the output file.

* **timeformat** [*integer*]: format of the time array: (0) seconds from the starting date, (1) time fraction, or (2) date and time format.

### INIT_SEEDING
Here you can define all the parameters to seed trajectories in TRACMASS (more info can be found [here](/docs/components/main_modules/#mod_seedf90)).

* **nff** [*integer*]: time arrow of TRACMASS: (1) run forward trajectories and (-1) backward trajectories.

* **isec** [*integer*]: seeding section (1) zonal wall, (2) meridional wall, and (3) vertical wall.

* **idir** [*integer*]: direction of initial fluxes (1) only positive fluxes are seeded, and (-1) only negative fluxes are seeded.

* **nqua** [*integer*]: defines how many particles are initiliased per grid cell (1) constant number set by **partQuant**, (2) all trajectories reflect the same transport set by **partQuant**.

* **partQuant** [*integer*]:  number of trajectories per grid cell (if nqua is one) or the mass/volume transport per trajectory (if nqua is two).

* **loneparticle** [*integer*]: trajectory number to run a lonely trajectory. The default value is set to zero (run all trajectories).

* **SeedType** [*integer*]: defines the seeding type (1) using a seeding box defined by ist,jst,kst, or (2) using indexes from a file.

* **ist1** and **ist2** [*integer*]: define the first and last zonal index of the seeding box (seedType=1)

* **jst1** and **jst2** [*integer*]: define the first and last meridional index of the seeding box (seedType=1)

* **kst1** and **kst2** [*integer*]: define the first and last vertical index of the seeding box (seedType=1)

* **seeddir** [*character*]: path to the directory where the seeding file is stored (seedType=2).

* **seedfile** [*character*]: name of the seeding file (seedType=2).

* **maskfile** [*character*]: name of the masking file (seedType=1).

* **seedTime** [*integer*]: defines the time seeding type (1) using a time range, or (2) using indexes from a file.

* **tst1** and **tst2** [*integer*]: defines the first and last time steps to seed trajectories (seedTime=1).

* **timeFile** [*character*]: name of the time seeding file (seedTime=2).

### INIT_TRACERS
Here you can activate tracers, define their names and properties, as well as set some modifications (more info can be found [here](/docs/components/main_modules/#mod_tracersf90)).

* **l_tracers** [*logical*]:  activate tracers. Default value is **FALSE**.

* **l_swtraj** [*logical*]: activate salt/water trajectories. Default value is **FALSE**.

* **tracertrajscale** [*real*]: scale factor applied on the tracer which is used to compute salt/water trajectories. Default value is one.

* **tracername** [*character, array*]: name of the tracers.

* **tracershift** [*real, array*]: add a shift value to the tracer array. Default values is **zero**.

* **tracerscale** [*real, array*]: multiple the tracer value by a scale factor. Default values is **one**.

* **tracerunit** [*character, array*]: tracer units.

* **tracervarname** [*character, array*]: variable name of the tracer.

* **traceraction** [*character, array*]: action associated to the variable 'read' or 'compute'.

* **tracermin** [*real, array*]: minimum value of the tracer used to define the tracer coordinate space when stream functions are computed.

* **tracermax** [*real, array*]: maximum value of the tracer used to define the tracer coordinate space when stream functions are computed.

* **tracerdimension** [*character, array*]: defines the number of dimensions of the tracer, '2D' or '3D'.

### INIT_TRACERS_SEEDING
Here you can define the maximum and mimimum tracer values when particles are seeded (an example can be found [here](/blog/nemo/)).

* **tracer0min** [*real, array*]: minimum value of the tracer to be seeded. The default values is **-9999**.

* **tracer0max** [*real, array*]: maximum value of the tracer to be seeded. The default values is **9999**.

### INIT_KILLZONES
Here you can define the maximum time limit,  as well as define the regions where trajectories are terminated (some examples are shown [here](/blog/nemo/) and [here](/blog/aviso/)). For a detail description on how the kill zones work check the [*projets* folder](/docs/components/project/#kill_zonesf90)) section.

* **timax** [*real*]: time limit before trajectories are terminated, calculated in days.

* **l_nosurface** [*logical*]: prevent trajectories from reaching the last vertical level (sea surface/ land surface). Default value is **.FALSE.**.

* **exitype** [*integer*]: selects the type of killing zones (1) defined by a regular box, (2) defined by a tracer value, (3) a combined tracer-geographical zone, and (4) hard coded killing zone.

* **ienw** and **iene** [*integer, array*]: define the western and eastern index of the killing zone (exitType=1).

* **jens** and **jenn** [*integer, array*]: define the southern and northern index of the killing zone (exitType=1).

* **tracerchoice** [*integer, array*]: defines the tracers that are used to defined the killing zone (exitType=2 or exitType=3). The index is given by the order of the tracer in **tracername**.

*  **tracere** [*real, array*]: value of the tracer that defines the killing zone (exitType=2 or exitType=3).

*  **maxormin** [*integer, array*]: sets the value of **tracere** to a (1) maximum or (-1) minimum value.

### INIT_POSTPROCESS
Here you can activate the stream function and/or the tracer divergence calculation (some examples are shown [here](/blog/nemo/) and [here](/blog/aviso/)). For a detail description on how the stream functions are computed check the [*mod_stream.F90*](/docs/components/main_modules/#mod_streamf90)) section. For information about the divergence calculation check [*mod_divergence.F90*](/docs/components/main_modules/#mod_divergencef90)) section instead.

* **l_psi** [*logical*]: activate stream function calculation.

* **l_offline** [*logical*]: compute the stream functions offline. Default value is **TRUE**.

* **dirpsi** [*integer, array*]: direction of integration of streamfunctions.

* **xyflux** [*integer*]: compute barotropic fluxes using **uflux** (1) or **vflux** (2). Default value is **1**.

* **l_divergence** [*logical*]: activate the calculation tracer divergence.

* **divcons** [*real, array*]: constants applied to the tracer divergence.

### INIT_ACTIVE
Here you can activate the Lagrangian diffusion scheme (for more information check [here](/docs/components/main_modules/#mod_diffusionf90)).

* **l_diffusion** [*logical*]: activates the addition of a random displacement to trajectories. Default values is **FALSE**.

* **ah** [*real*]: horizontal diffusion constant.

* **av** [*real*]: vertical diffusion constant.
