---
title: Main program
weight: 0
excerpt: lorem-ipsum
layout: docs
---
The present chapter describes the main program TRACMASS and the different running options.

***
## TRACMASS.F90

<p>This is how the TRACMASS main program works:
	<br><br>

	1 - First the namelist is read (<strong>init_namelist</strong>) and the tracers are initialised (<strong>init_tracer</strong>).<br><br>
	2 - Then the subdomain is defined (<strong>init_subdomain</strong>) and all the arrays are allocated (<strong>init_alloc</strong>).<br><br>3 - If <strong>norun</strong> is false the main subroutines to compute trajectories are called.</p>
 <p style="margin-left: 20px;">3.1 - The grid variables are defined (<strong>setup_grid</strong>),the calendar (<strong>init_calendar</strong>) and the seeding are initialised (<strong>init_seed</strong>).

	<br><br>3.2 - If online stream function are activated, the fluxes are allocated (<strong>init_stream</strong>).

	<br><br>3.3 - The main loop is called where the trajectories are computed (<strong>loop</strong>).</p>

<p>4 - Then, the output is postprocessed.</p>

<p style="margin-left: 20px;">
	4.1 - If a summary is computed the the subroutine <strong>postprocessing</strong> is called.<br><br>
	4.2 - If only offline streamfunctions are computed (no summary), the subroutine <strong>compute_stream</strong> is called.</p>

***
## *./runtracmass* running arguments
TRACMASS can be run with different arguments that can be combined:

* **rerun**: rerun TRACMASS by seeding only the trajectories that are stored in the *rerun* file. The model will crash if no *rerun* file can be found.

* **norun**: run TRACMASS without the computation of trajectories. This argument is useful to compute offline stream functions from output files.

* **summary**: include a more detailed summary of the trajectories and their transport at the end of the run.

***
## TRACMASS unix file tree

<p align="center">
  <img width="100%" src="/images/fig_tracmass_tree.png">
</p>
