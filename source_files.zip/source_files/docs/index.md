---
title: Welcome to TRACMASS' documentation
layout: docs
---
**TRACMASS** is a Lagrangian trajectory code for ocean and atmospheric general circulation models. The code makes it possible to estimate water paths, Lagrangian stream functions (barotropic, overturning, etc.), exchange times, etc. **TRACMASS** has been used in studies of the global ocean circulation, of sea circulation in the Baltic Sea, the Mediterranean Sea and in coastal regions.

The code is written in FORTRAN 90 with modules and runs on UNIX platforms such as MAC OS X and Linux.

TRACMASS has been set up to run with velocities integrated with models such as NEMO or IFS-ECMWF, of satellite datasets such as AVISO.

<style>
      .button {
        display: inline-block;
        padding: 10px 20px;
        text-align: center;
        text-decoration: none;
        color: #ffffff;
        background-color: #002596;
        border-radius: 6px;
        outline: none;
      }
    </style>
***
# What's new in version 7.0
The current version of **TRACMASS** (v 7.0) includes the following new features:

* The code has been thoroughly cleaned up 
* Supported test cases from:

  | Ocean circulation models: | **NEMO, MOM5, ROMS**
	|Satellite ocean current data | **AVISO**|
	|Atmospheric circulation model data| **IFS** (ERA-Interim, EC-Earth)|
* Any tracer can be followed e.g. biogeochemical tracers or chemical compounds in the atmosphere.
* A new quick-start guide and a comprehensive documentation.

*** 

<div class="note">
  <strong>Note:</strong> <br>
	You can find previous versions of <strong>TRACMASS</strong> here:<br>
	<br>
	<center>
	<a class="button" style="background-color: #004C94;" href="https://github.com/TRACMAS/Tracmass_previous">Get older version here</a>
	</center>
	<br>
	<strong> Cite this version as:</strong> <br>
	Jönsson, B., K. Döös, and J. Kjellsson (2015), TRACMASS: Lagrangian trajectory code, doi:10.5281/zenodo.34157 
	<br>
	<br>
	<strong> Reference paper:</strong> <br>
	Döös, K., B. Jönsson, and J. Kjellsson (2017), Evaluation of oceanic and atmospheric trajectory schemes in the TRACMASS trajectory model v6.0, Geoscientific Model Development, 10(4), 1733--1749, 10.5194/gmd-10-1733-2017. 
<a href="https://gmd.copernicus.org/articles/10/1733/2017/">Link</a>

</div>