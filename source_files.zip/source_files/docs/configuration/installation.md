---
title: Installation
weight: 1
layout: docs
---
<div class="note">
  <strong>Technical note:</strong> <br>
	<strong>TRACMASS</strong> is written in FORTRAN 90 with modules and runs on UNIX platforms such as MAC OS X and Linux. For certain configurations netCDF libraries are also required.
</div>

<p><strong>1.</strong> -  Download the code </p>

    git clone https://github.com/TRACMASS/Tracmass.git

<p><strong>2.</strong>  -  Enter the TRACMASS directory </p>

    cd Tracmass

<p><strong>3.</strong>   - Modify the <strong>Makefile</strong> to fit your system. You will need to set ARCH, which is the name of your system, i.e. tetralith. You will also need to configure how TRACMASS should find the netCDF libraries, if at all. For most systems, we recommend the option <em>automatic-44</em>.</p>

<p> Make sure in <strong>Makefile</strong> both PROJECT and CASE are set to Theoretical. In this case, TRACMASS will use a simple oscillating velocity field to trace trajectories.</p>

<p><strong>4.</strong>  - Then you can run the make command</p>

    make

<p><strong>5.</strong>  - Run the code by typing</p>

    ./runtracmass
