---
title: Configuration
excerpt: ''
layout: docs
---
The present chapter will present how to configure and run the **TRACMASS** Lagrangian trajectory model, as well as how to configure a customised experiment.

***

Here are the articles in this section:
