---
title: Home
sections:
  - section_id: TRACMASS intro
    type: section_hero
    title: TRACMASS
    image: images/headers_footer/fig_header.png
    content: >-
      **TRACMASS** is a Lagrangian trajectory code for ocean and atmospheric
      general circulation models. The code makes it possible to estimate water
      paths, Lagrangian stream functions (barotropic, overturning, etc.),
      exchange times, etc.
    actions:
      - label: Get code
        url: 'https://github.com/TRACMASS/tracmass'
        style: primary
  - section_id: features
    type: section_grid
    col_number: three
    grid_items:
      - title: Documentation
        content: |-
          Learn about:
          * how to set up **TRACMASS**.
          * how to design your own experiment.
          * how the different components of **TRACMASS** work.
          * how to postprocess your **TRACMASS** output data.
        actions:
          - label: Get Started
            url: /docs
            style: link
      - title: Examples
        content: >-
          Check our gallery with different **TRACMASS** results for different
          datasets and examples on how the **TRACMASS** features work.
        actions:
          - label: View Gallery
            url: /examples
            style: link
        title_url: ''
      - title: Contact & FAQ
        content: >-
          Check our FAQ and contact information in case you have any problem or
          comment about **TRACMASS**
        actions:
          - label: Learn More
            url: /contact
            style: link
  - section_id: quickstart
    type: section_content
    image: images/headers_footer/fig_sketch.png
    image_position: left
    title: Quickstart
    content: "<p>1. - Download the code:</p>\n\n\tgit clone https://github.com/TRACMASS/Tracmass.git\n\n<p>2. -  Modify the <em>Makefile</em> to fit your system. </p>\n\n<p>3. - Then you can run the make command: </p>\n      \n    make\n\n<p>4. - Run <strong>TRACMASS</strong> by typing: </p>\n\n    ./runtracmass"
    actions:
      - label: View Documentation
        url: /docs/configuration/quick-start
        style: primary
  - title: 'Cite as:'
    section_id: citation
    subtitle: >-
      Cite as  Aldama-Campino, Aitor, Döös, Kristofer, Kjellsson, Joakim, &
      Jönsson, Bror. (2020, December 17). TRACMASS: Formal release of version
      7.0 (Version v7.0-beta). Zenodo. http://doi.org/10.5281/zenodo.4337926
    actions:
      - label: Link to Zenodo
        url: 'https://zenodo.org/record/4337926'
        style: secondary
        icon_class: dev
        new_window: false
        no_follow: false
        type: action
    type: section_cta
layout: advanced
---
